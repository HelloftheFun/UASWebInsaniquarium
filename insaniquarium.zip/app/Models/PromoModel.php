<?php

namespace App\Models;

use CodeIgniter\Model;

class PromoModel extends Model
{

    protected $table = 'promo';
    protected $allowedFields = ['id', 'Gambar', 'Judul' , 'isi', 'class'];

    public function getPromo($id = false)
    {
        if ($id == false) {
            return $this->findAll();
        }

        return $this->where(['id' => $id])->first();
    }
    public function search($keyword)
    {
       // $builder = $this->table('orang');
       // $builder->like('name', $keyword);
       // return $builder;
 
       return $this->table('promo')->like('Judul', $keyword)->orLike('isi', $keyword);
    }
}