<?php

namespace App\Models;

use CodeIgniter\Model;

class PakanModel extends Model
{

    protected $table = 'aksesorisdanpakan';
    protected $allowedFields = ['id', 'Gambar', 'Merk' , 'Keterangan' , 'Harga'];

    public function getPakan($id = false)
    {
        if ($id == false) {
            return $this->findAll();
        }

        return $this->where(['id' => $id])->first();
    }
    public function search($keyword)
    {
       // $builder = $this->table('orang');
       // $builder->like('name', $keyword);
       // return $builder;
 
       return $this->table('aksesorisdanpakan')->like('Merk', $keyword)->orLike('Keterangan', $keyword);
    }
}