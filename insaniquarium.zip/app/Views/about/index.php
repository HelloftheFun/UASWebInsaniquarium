

<!doctype html>
<html lang="en">
  <head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="megakit,business,company,agency,multipurpose,modern,bootstrap4">
  
  <meta name="author" content="themefisher.com">

  <title>Megakit| Html5 Agency template</title>

  <!-- bootstrap.min css -->
  <link rel="stylesheet" href="<?= base_url('plugins/bootstrap/css/bootstrap.min.css')?>">

  <!-- Icon Font Css -->
  <link rel="stylesheet" href="<?= base_url('plugins/themify/css/themify-icons.css')?>">
  <link rel="stylesheet" href="<?=base_url('plugins/fontawesome/css/all.css')?>">
  <link rel="stylesheet" href="<?= base_url('plugins/magnific-popup/dist/magnific-popup.css')?>">
  <!-- Owl Carousel CSS -->
  <link rel="stylesheet" href="<?= base_url('plugins/slick-carousel/slick/slick.css')?>">
  <link rel="stylesheet" href="<?= base_url('plugins/slick-carousel/slick/slick-theme.css')?>">

  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="<?= base_url('css/style.css')?>">

</head>

<body>

<!-- Header Start --> 

<header class="navigation">
	<div class="header-top ">
		<div class="container">
			<div class="row justify-content-between align-items-center">
				<div class="col-lg-2 col-md-4">
					<div class="header-top-socials text-center text-lg-left text-md-left">
						<a href="https://www.facebook.com/themefisher" target="_blank"><i class="ti-facebook"></i></a>
						<a href="https://twitter.com/themefisher" target="_blank"><i class="ti-twitter"></i></a>
						<a href="https://github.com/themefisher/" target="_blank"><i class="ti-github"></i></a>
					</div>
				</div>
				<div class="col-lg-10 col-md-8 text-center text-lg-right text-md-right">
					<div class="header-top-info">
						<a href="tel:+23-345-67890">Call Us : <span>+23-345-67890</span></a>
						<a href="mailto:support@gmail.com" ><i class="fa fa-envelope mr-2"></i><span>support@gmail.com</span></a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<nav class="navbar navbar-expand-lg  py-4" id="navbar">
		<div class="container">
		  <a class="navbar-brand" href="index.html">
		  	Mega<span>kit.</span>
		  </a>

		  <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
			<span class="fa fa-bars"></span>
		  </button>
	  
		  <div class="collapse navbar-collapse text-center" id="navbarsExample09">
			<ul class="navbar-nav ml-auto">
			  <li class="nav-item active">
				<a class="nav-link" href="<?= base_url()?>">Home <span class="sr-only">(current)</span></a>
			  </li>
			  <li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About</a>
					<ul class="dropdown-menu" aria-labelledby="dropdown03">
						<li><a class="dropdown-item" href="about.html">Our company</a></li>
						<li><a class="dropdown-item" href="pricing.html">Pricing</a></li>
					</ul>
			  </li>
			   <li class="nav-item"><a class="nav-link" href="service.html">Services</a></li>
			   <li class="nav-item"><a class="nav-link" href="project.html">Portfolio</a></li>
			   <li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Blog</a>
					<ul class="dropdown-menu" aria-labelledby="dropdown05">
						<li><a class="dropdown-item" href="blog-grid.html">Blog Grid</a></li>
						<li><a class="dropdown-item" href="blog-sidebar.html">Blog with Sidebar</a></li>

						<li><a class="dropdown-item" href="blog-single.html">Blog Single</a></li>
					</ul>
			  </li>
			   <li class="nav-item"><a class="nav-link" href="contact.html">Contact</a></li>
			</ul>

			<form class="form-lg-inline my-2 my-md-0 ml-lg-4 text-center">
			  <a href="contact.html" class="btn btn-solid-border btn-round-full">Get a Quote</a>
			</form>
		  </div>
		</div>
	</nav>
</header>

<!-- Header Close --> 

<div class="main-wrapper ">
<section class="page-title bg-1">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="block text-center">
          <span class="text-white">About Us</span>
          <h1 class="text-capitalize mb-4 text-lg">Our Company</h1>
          <ul class="list-inline">
            <li class="list-inline-item"><a href="index.html" class="text-white">Home</a></li>
            <li class="list-inline-item"><span class="text-white">/</span></li>
            <li class="list-inline-item"><a href="#" class="text-white-50">About Us</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- Section About Start -->
<section class="section about-2 position-relative">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6">
				<div class="about-item pr-3 mb-5 mb-lg-0">
					<span class="h6 text-color">What we are</span>
					<h2 class="mt-3 mb-4 position-relative content-title">We are dynamic team of creative people</h2>
					<p class="mb-5">We provide consulting services in the area of IFRS and management reporting, helping companies to reach their highest level. We optimize business processes, making them easier.</p>

					<a href="#" class="btn btn-main btn-round-full">Get started</a>
				</div>
			</div>
			<div class="col-lg-6 col-md-6">
				<div class="about-item-img">
					<img src="images/about/home-7.jpg" alt="" class="img-fluid">
				</div>
			</div>
		</div>
	</div>
</section>

<!-- Section About End -->
 
<section class="about-info section pt-0">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-4 col-md-6 col-sm-6">
				<div class="about-info-item mb-4 mb-lg-0">
					<h3 class="mb-3"><span class="text-color mr-2 text-md ">01.</span>Our Mission</h3>
					<p>llum similique ducimus accusamus laudantium praesentium, impedit quaerat, itaque maxime sunt deleniti voluptas distinctio .</p>
				</div>		
			</div>
			<div class="col-lg-4 col-md-6 col-sm-6">
				<div class="about-info-item mb-4 mb-lg-0">
					<h3 class="mb-3"><span class="text-color mr-2 text-md">02.</span>Vission</h3>
					<p>llum similique ducimus accusamus laudantium praesentium, impedit quaerat, itaque maxime sunt deleniti voluptas distinctio .</p>
				</div>		
			</div>
			<div class="col-lg-4 col-md-6 col-sm-6">
				<div class="about-info-item mb-4 mb-lg-0">
					<h3 class="mb-3"><span class="text-color mr-2 text-md">03.</span>Our Approach</h3>
					<p>llum similique ducimus accusamus laudantium praesentium, impedit quaerat, itaque maxime sunt deleniti voluptas distinctio .</p>
				</div>		
			</div>
		</div>
	</div>
</section>

<!-- section Counter Start -->
<section class="section counter bg-counter">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="counter-item text-center mb-5 mb-lg-0">
					<i class="ti-check color-one text-md"></i>
					<h3 class="mt-2 mb-0 text-white"><span class="counter-stat font-weight-bold">1730</span> +</h3>
					<p class="text-white-50">Project Done</p>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="counter-item text-center mb-5 mb-lg-0">
					<i class="ti-flag color-one text-md"></i>
					<h3 class="mt-2 mb-0 text-white"><span class="counter-stat font-weight-bold">125 </span>M </h3>
					<p class="text-white-50">User Worldwide</p>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="counter-item text-center mb-5 mb-lg-0">
					<i class="ti-layers color-one text-md"></i>
					<h3 class="mt-2 mb-0 text-white"><span class="counter-stat font-weight-bold">39</span></h3>
					<p class="text-white-50">Availble Country</p>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="counter-item text-center">
					<i class="ti-medall color-one  text-md"></i>
					<h3 class="mt-2 mb-0 text-white"><span class="counter-stat font-weight-bold">14</span></h3>
					<p class="text-white-50">Award Winner </p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- section Counter End  -->
<!--  Section Services Start -->
<section class="section team">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-7 text-center">
				<div class="section-title">
					<span class="h6 text-color">Our Team</span>
					<h2 class="mt-3 content-title">Expert Team member to get best service</h2>
				</div>
			</div>
		</div>

		<div class="row justify-content-center">
			<div class="col-lg-4 col-md-6 col-sm-6">
				<div class="team-item-wrap mb-5">
					<div class="team-item position-relative">
						<img src="images/team/team-1.jpg" alt="" class="img-fluid w-100">
						<div class="team-img-hover">
							<ul class="team-social list-inline">
								<li class="list-inline-item">
									<a href="#" class="facebook"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="twitter"><i class="fab fa-twitter" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="instagram"><i class="fab fa-instagram" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="linkedin"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="team-item-content">
						<h4 class="mt-3 mb-0 text-capitalize">Justin hammer</h4>
						<p>Digital Marketer</p>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6 col-sm-6">
				<div class="team-item-wrap mb-5">
					<div class="team-item position-relative">
						<img src="images/team/team-2.jpg" alt="" class="img-fluid w-100">
						<div class="team-img-hover">
							<ul class="team-social list-inline">
								<li class="list-inline-item">
									<a href="#" class="facebook"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="twitter"><i class="fab fa-twitter" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="instagram"><i class="fab fa-instagram" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="linkedin"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="team-item-content">
						<h4 class="mt-3 mb-0 text-capitalize">Jason roy</h4>
						<p>UI/UX Designer</p>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6 col-sm-6">
				<div class="team-item-wrap mb-5 ">
					<div class="team-item position-relative">
						<img src="images/team/team-3.jpg" alt="" class="img-fluid w-100">
						<div class="team-img-hover">
							<ul class="team-social list-inline">
								<li class="list-inline-item">
									<a href="#" class="facebook"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="twitter"><i class="fab fa-twitter" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="instagram"><i class="fab fa-instagram" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="linkedin"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="team-item-content">
						<h4 class="mt-3 mb-0 text-capitalize">Henry oswald</h4>
						<p>Developer</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-sm-6">
				<div class="team-item-wrap mb-5 mb-lg-0">
					<div class="team-item position-relative">
						<img src="images/team/team-4.jpg" alt="" class="img-fluid w-100">
						<div class="team-img-hover">
							<ul class="team-social list-inline">
								<li class="list-inline-item">
									<a href="#" class="facebook"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="twitter"><i class="fab fa-twitter" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="instagram"><i class="fab fa-instagram" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="linkedin"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="team-item-content">
						<h4 class="mt-3 mb-0 text-capitalize">David Williams</h4>
						<p>Senior Marketer</p>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6 col-sm-6">
				<div class="team-item-wrap mb-5 mb-lg-0">
					<div class="team-item position-relative">
						<img src="images/team/team-6.jpg" alt="" class="img-fluid w-100">
						<div class="team-img-hover">
							<ul class="team-social list-inline">
								<li class="list-inline-item">
									<a href="#" class="facebook"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="twitter"><i class="fab fa-twitter" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="instagram"><i class="fab fa-instagram" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="linkedin"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="team-item-content">
						<h4 class="mt-3 mb-0 text-capitalize">Peter Odin</h4>
						<p>App Developer</p>
					</div>
				</div>
			</div>

			<div class="col-lg-4 col-md-6 col-sm-6">
				<div class="team-item-wrap mb-5 mb-lg-0 ">
					<div class="team-item position-relative">
						<img src="images/team/team-5.jpg" alt="" class="img-fluid w-100">
						<div class="team-img-hover">
							<ul class="team-social list-inline">
								<li class="list-inline-item">
									<a href="#" class="facebook"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="twitter"><i class="fab fa-twitter" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="instagram"><i class="fab fa-instagram" aria-hidden="true"></i></a>
								</li>
								<li class="list-inline-item">
									<a href="#" class="linkedin"><i class="fab fa-linkedin-in" aria-hidden="true"></i></a>
								</li>
							</ul>
						</div>
					</div>
					<div class="team-item-content">
						<h4 class="mt-3 mb-0 text-capitalize">David Spensor</h4>
						<p>Project Manager</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!--  Section Services End -->
<!-- Section Testimonial Start -->
<section class="section testimonial bg-gray">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-7 text-center">
				<div class="section-title">
					<span class="h6 text-color">Clients testimonial</span>
					<h2 class="mt-3 content-title">Check what's our clients say about us</h2>
				</div>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="testimonial-wrap">
			<div class="testimonial-item position-relative">
				<i class="ti-quote-left text-color"></i>

				<div class="testimonial-item-content">
					<p class="testimonial-text">Quam maiores perspiciatis temporibus odio reiciendis error alias debitis atque consequuntur natus iusto recusandae numquam corrupti facilis blanditiis.</p>

					<div class="testimonial-author">
						<h5 class="mb-0 text-capitalize">Thomas Johnson</h5>
						<p>Excutive Director,themefisher</p>
					</div>
				</div>
			</div>
			<div class="testimonial-item position-relative">
				<i class="ti-quote-left text-color"></i>

				<div class="testimonial-item-content">
					<p class="testimonial-text">Consectetur adipisicing elit. Quam maiores perspiciatis temporibus odio reiciendis error alias debitis atque consequuntur natus iusto recusandae .</p>

					<div class="testimonial-author">
						<h5 class="mb-0 text-capitalize">Mickel hussy</h5>
						<p>Excutive Director,themefisher</p>
					</div>
				</div>
			</div>
			<div class="testimonial-item position-relative">
				<i class="ti-quote-left text-color"></i>

				<div class="testimonial-item-content">
					<p class="testimonial-text">Quam maiores perspiciatis temporibus odio reiciendis error alias debitis atque consequuntur natus iusto recusandae numquam corrupti.</p>

					<div class="testimonial-author">
						<h5 class="mb-0 text-capitalize">James Watson</h5>
						<p>Excutive Director,themefisher</p>
					</div>
				</div>
			</div>
			<div class="testimonial-item position-relative">
				<i class="ti-quote-left text-color"></i>

				<div class="testimonial-item-content">
					<p class="testimonial-text">Consectetur adipisicing elit. Quam maiores perspiciatis temporibus odio reiciendis error alias debitis atque consequuntur natus iusto recusandae .</p>

					<div class="testimonial-author">
						<h5 class="mb-0 text-capitalize">Mickel hussy</h5>
						<p>Excutive Director,themefisher</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Section Testimonial End -->

<!-- footer Start -->
<footer class="footer section">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="widget">
					<h4 class="text-capitalize mb-4">Company</h4>

					<ul class="list-unstyled footer-menu lh-35">
						<li><a href="#">Terms & Conditions</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Support</a></li>
						<li><a href="#">FAQ</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-2 col-md-6 col-sm-6">
				<div class="widget">
					<h4 class="text-capitalize mb-4">Quick Links</h4>

					<ul class="list-unstyled footer-menu lh-35">
						<li><a href="#">About</a></li>
						<li><a href="#">Services</a></li>
						<li><a href="#">Team</a></li>
						<li><a href="#">Contact</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="widget">
					<h4 class="text-capitalize mb-4">Subscribe Us</h4>
					<p>Subscribe to get latest news article and resources  </p>

					<form action="#" class="sub-form">
						<input type="text" class="form-control mb-3" placeholder="Subscribe Now ...">
						<a href="#" class="btn btn-main btn-small">subscribe</a>
					</form>
				</div>
			</div>

			<div class="col-lg-3 ml-auto col-sm-6">
				<div class="widget">
					<div class="logo mb-4">
						<h3>Mega<span>kit.</span></h3>
					</div>
					<h6><a href="tel:+23-345-67890" >Support@megakit.com</a></h6>
					<a href="mailto:support@gmail.com"><span class="text-color h4">+23-456-6588</span></a>
				</div>
			</div>
		</div>
		
		<div class="footer-btm pt-4">
			<div class="row">
				<div class="col-lg-4 col-md-12 col-sm-12">
					<div class="copyright">
						&copy; Copyright Reserved to <span class="text-color">Megakit.</span> by <a href="https://themefisher.com/" target="_blank">Themefisher</a>
					</div>
				</div>

				<div class="col-lg-4 col-md-12 col-sm-12">
					<div class="copyright">
					Distributed by  <a href="https://themewagon.com/" target="_blank">Themewagon</a>
					</div>
				</div>
				<div class="col-lg-4 col-md-12 col-sm-12 text-left text-lg-left">
					<ul class="list-inline footer-socials">
						<li class="list-inline-item"><a href="https://www.facebook.com/themefisher"><i class="ti-facebook mr-2"></i>Facebook</a></li>
						<li class="list-inline-item"><a href="https://twitter.com/themefisher"><i class="ti-twitter mr-2"></i>Twitter</a></li>
						<li class="list-inline-item"><a href="https://www.pinterest.com/themefisher/"><i class="ti-linkedin mr-2 "></i>Linkedin</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</footer>
   
    </div>

    <!-- 
    Essential Scripts
    =====================================-->

    
    <!-- Main jQuery -->
    <script src="<?= base_url('plugins/jquery/jquery.js')?>"></script>
    <script src="<?= base_url('js/contact.js')?>"></script>
    <!-- Bootstrap 4.3.1 -->
    <script src="<?= base_url('plugins/bootstrap/js/popper.js')?>"></script>
    <script src="<?= base_url('plugins/bootstrap/js/bootstrap.min.js')?>"></script>
   <!--  Magnific Popup-->
    <script src="<?= base_url('plugins/magnific-popup/dist/jquery.magnific-popup.min.js')?>"></script>
    <!-- Slick Slider -->
    <script src="<?= base_url('plugins/slick-carousel/slick/slick.min.js')?>"></script>
    <!-- Counterup -->
    <script src="<?= base_url('plugins/counterup/jquery.waypoints.min.js')?>"></script>
    <script src="<?= base_url('plugins/counterup/jquery.counterup.min.js')?>"></script>

    <!-- Google Map -->
    <script src="plugins/google-map/map.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkeLMlsiwzp6b3Gnaxd86lvakimwGA6UA&callback=initMap"></script>    
    
    <script src="<?= base_url('js/script.js')?>"></script>

  </body>
  </html>