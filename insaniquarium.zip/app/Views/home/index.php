<!DOCTYPE html>
<html lang="en">

<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>Insaniquarium</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="<?= base_url('css/bootstrap.min.css')?>">
    <!-- style css -->
    <link rel="stylesheet" href="<?= base_url('css/style.css')?>">
    <!-- Responsive-->
    <link rel="stylesheet" href="<?= base_url('css/responsive.css')?>">
    
    <!-- fevicon -->
    <link rel="icon" href="<?= base_url('images/fevicon.png')?>" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="<?= base_url('/css/jquery.mCustomScrollbar.min.css')?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('css/owl.carousel.min.css')?>">
    <link rel="stylesheet" href="<?= base_url('css/owl.theme.default.min.css')?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<!-- body -->

<body class="main-layout ">
   
    <!-- header -->
    <header>
        <!-- header inner -->
        <div class="header">

            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                        <div class="full">
                            <div class="center-desk">
                                <div class="logo">
                                    <a href="home/index"> <img src="<?= base_url('images/Logo.png')?>" alt="#"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                        <div class="menu-area">
                            <div class="limit-box">
                                <nav class="main-menu">
                                    <ul class="menu-area-main">
                                        <li class="active"> <a href="/" alt="#">Home</a> </li>
                    
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- end header inner -->
    </header>
    <!-- end header -->

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">

  <?php
   $i = 0;
   foreach ($promo as $prm) {
      $actives = '';
      if ($i == 0){
         $actives = 'active';
   }
   ?>

    <li data-target="#carouselExampleIndicators" data-slide-to="<?= $i; ?>" class="<?= $actives; ?>"></li>
    <?php $i++; } ?>
  </ol>

  
  <!-- Wrapper for slides -->
  <div class="carousel-inner"> 
  <?php
   $i = 0;
   foreach ($promo as $prm) {
      $actives = '';
      if ($i == 0){
         $actives = 'active';
   }
   ?>
    <div class="carousel-item <?= $actives; ?>">
      <img src="/images/promo/<?= $prm['Gambar'] ?>">
      </div>
    <?php $i++; } ?>
    </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

 <!-- brand -->
 <div class="brand">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="titlepage">
                        <h2>Cari apa?</h2>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <div class="container">
                <div class="row">

			
                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 margin">
                        <div class="about_box">
                            <img src="<?= base_url('images/ikan/TSN.png')?>" alt="img" /><br><br><br><br>
                            <a href="<?= base_url('home/ikan')?>" class="read-more">Ikan</a>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 margin">
                        <div class="about_box">
                            <img src="<?= base_url('images/Aquarium.png')?>" alt="img" /><br><br><br><br>
                            <a href="<?= base_url('home/aquarium')?>" class="read-more">Aquarium</a>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-3 margin">
                        <div class="about_box">
                            <img src="<?= base_url('images/pakan.png')?>" alt="img" /><br><br><br><br>
                            <a href="<?= base_url('home/pakan')?>" class="read-more">Pakan dan Aksesoris</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- end brand -->

   
    <!-- contact -->
    <div class="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   
                </div>
            </div>
        </div>
    </div>
    <!-- end contact -->

    <!-- footer -->
    <footer>
        <div id="contact" class="footer">
            <div class="container">
                <div class="row pdn-top-20">
                    <div class="col-md-12 ">
                        <div class="footer-box">
                            <div class="headinga">
                                <span>Jl. Raden Fatah, Ciledug, Tangerang</span>
                                <p>+62-895-3743-09427
                                    <br>wahid_ari@ymail.com</p>
                            </div>
                            <ul class="location_icon">
                                <li> <a href="https://www.facebook.com/wahid.arisaputra"><i class="fa fa-facebook-f"></i></a></li>
                                <li> <a href="https://twitter.com/Co_mar_?lang=id"><i class="fa fa-twitter"></i></a></li>
                                <li> <a href="https://www.instagram.com/mar.co.mar/"><i class="fa fa-instagram"></i></a></li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright">
                <div class="container">
                    <p>© 2021 Copyright by Insaniquarium</p>
                </div>
            </div>
        </div>
    </footer>
    <!-- end footer -->
    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-3.0.0.min.js"></script>
    <script src="js/nouislider.min.js"></script>
    <script src="js/plugin.js"></script>
    <script>
    $('.carousel').carousel ({
        interval : 2000
    })
    </script>
    <!-- sidebar -->
    <script src="<?= base_url('js/jquery.mCustomScrollbar.concat.min.js')?>"></script>
    <script src="<?= base_url('js/custom.js')?>"></script>
    <!-- javascript -->
    <script src="<?= base_url('js/owl.carousel.js')?>"></script>
    <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
    <script> 
        $(document).ready(function() {
            $(".fancybox").fancybox({
                openEffect: "none",
                closeEffect: "none"
            });

            $(".zoom").hover(function() {

                $(this).addClass('transition');
            }, function() {

                $(this).removeClass('transition'); 
            });
        });
    </script>
</body>
</html>
<?= base_url('') ?>