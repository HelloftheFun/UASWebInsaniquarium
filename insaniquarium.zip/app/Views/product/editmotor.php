

<!DOCTYPE html>
<html lang="en">

<head>
    <title>FGM Admin Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css"></script>
    <script src="https://use.fontawesome.com/bb6feaa7cf.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/29.1.0/classic/ckeditor.js"></script>
    <script>
      function previewImg() {
         const gambar = document.querySelector('#gambar');
         const gambarLabel = document.querySelector('.custom-file-label');
         const imgPreview = document.querySelector('.img-preview');

         // untuk mengganti url
         gambarLabel.textContent = gambar.files[0].name;

         // untuk mengganti preview
         const fileGambar = new FileReader();
         fileGambar.readAsDataURL(gambar.files[0]);

         fileGambar.onload = function(e) {
            imgPreview.src = e.target.result;
         }
      }
   </script>

    <style>
        .fakeimg {
            height: 200px;
            background: #aaa;
        }
    </style>
</head>

<body>



    <div class="container">
   <div class="row">
      <div class="col-8">
         <h2 class="my-3">Edit Motor</h2>
         <form action="<?= base_url('/admin/update'); ?>" method="POST" enctype="multipart/form-data">
            <?= csrf_field(); ?>
            <input type="hidden" name="id" value="<?= $motor['id'] ?>" />
            <div class="form-group row">
               <label for="title" class="col-sm-2 col-form-label">Merk Motor</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control <?= ($validation->hasError('merk')) ? 'is-invalid' : ''; ?>" id="merk" name="merk" autofocus value="<?= (old('merk')) ? old('merk') : $motor['merk']?>">
                  <div class="invalid-feedback">
                     <?= $validation->getError('merk'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="tipe" class="col-sm-2 col-form-label">Tipe</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control <?= ($validation->hasError('tipe')) ? 'is-invalid' : ''; ?>" id="tipe" name="tipe" value="<?=$motor['tipe']?>">
                  <div class="invalid-feedback">
                     <?= $validation->getError('tipe'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="slug" class="col-sm-2 col-form-label">Slug</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control <?= ($validation->hasError('slug')) ? 'is-invalid' : ''; ?>" id="slug" name="slug" autofocus value="<?= (old('slug')) ? old('slug') : $motor['slug']?>">
                  <div class="invalid-feedback">
                     <?= $validation->getError('merk'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="kategori" class="col-sm-2 col-form-label">Kategori Motor</label>
               <div class="col-sm-10">
                  <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name="kategori">
                     <option selected><?= $motor['kategori'] ?> </option>
    <option value="SPORT BIKE">SPORT BIKE</option>
    <option value="NAKED BIKE"> NAKED BIKE</option>
    <option value="TRAIL BIKE"> TRAIL BIKE</option>
                  </select>
                  <div class="invalid-feedback">
                     <?= $validation->getError('kategori'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="spesifikasi" class="col-sm-2 col-form-label">Spesifikasi</label>
               <div class="col-sm-10">
               <textarea name="spesifikasi" class="form-control" id="spesifikasi" rows="10" cols="80" <?= ($validation->hasError('spesifikasi')) ? 'is-invalid' : ''; ?> value="<?= old('spesifikasi'); ?>" >
               <?=$motor['spesifikasi']?>
            </textarea>
                  <div class="invalid-feedback">
                     <?= $validation->getError('spesifikasi'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="ctg" class="col-sm-2 col-form-label">CTG Motor</label>
               <div class="col-sm-10">
                  <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name="ctg">
                     <option selected><?= $motor['ctg'] ?> </option>
    <option value="SPRT">SPRT</option>
    <option value="NKD"> NKD</option>
    <option value="TRL"> TRL</option>
                  </select>
                  <div class="invalid-feedback">
                     <?= $validation->getError('ctg'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="harga" class="col-sm-2 col-form-label">Harga</label>
               <div class="col-sm-10">
               <textarea name="harga" class="form-control" id="harga" rows="10" cols="80" <?= ($validation->hasError('harga')) ? 'is-invalid' : ''; ?> value="<?= old('harga'); ?>" >
               <?=$motor['harga']?>
            </textarea>
                  <div class="invalid-feedback">
                     <?= $validation->getError('harga'); ?>
                  </div>
               </div>
            </div>
               </div>
            </div>
            <div class="form-group row">
               <div class="col-sm-10">
                  <button type="submit" class="btn btn-primary">Edit Motor</button>
               </div>
            </div>
         </form>

      </div>
   </div>
</div>


</body>

</html>
    