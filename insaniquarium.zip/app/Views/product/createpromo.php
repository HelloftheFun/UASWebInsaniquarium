<!DOCTYPE html>
<html lang="en">

<head>
    <title>FGM Admin Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
    <script src="https://use.fontawesome.com/bb6feaa7cf.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
    <script>
      function previewImg() {
         const gambar = document.querySelector('#gambar');
         const gambarLabel = document.querySelector('.custom-file-label');
         const imgPreview = document.querySelector('.img-preview');

         // untuk mengganti url
         gambarLabel.textContent = gambar.files[0].name;

         // untuk mengganti preview
         const fileGambar = new FileReader();
         fileGambar.readAsDataURL(gambar.files[0]);

         fileGambar.onload = function(e) {
            imgPreview.src = e.target.result;
         }
      }
   </script>
    <style>
        .fakeimg {
            height: 200px;
            background: #aaa;
        }
    </style>
</head>
<div class="container">
    <h1>Input Promo</h1>
    <div class="row">
        <div class="col-sm-9">
            <form action="/admin/savepromo" method="POST" enctype="multipart/form-data">
            <div class="form-group row">
               <label for="cover" class="col-sm-2 col-form-label">Foto Produk</label>
               <div class="col-sm-3">
                  <img src="/images/default.png" class="img-thumbnail img-preview">
               </div>
               <div class="col-sm-7">
                  <div class="custom-file">
                     <input type="file" class="custom-file-input  <?= ($validation->hasError('gambar')) ? 'is-invalid' : ''; ?>" id="gambar" name="gambar" onchange="previewImg()">
                     <div class="invalid-feedback">
                        <?= $validation->getError('gambar'); ?>
                     </div> 
                     <label class="custom-file-label" for="gambar">Choose Image ..</label>
                  </div>
               </div>
            </div>
                <div class="form-group">
                    <label for="judul">Judul</label>
                    <input type="text" name="judul" class="form-control" id="judul" placeholder="Masukkan Merk">
                </div>
                <div class="form-group">
                    <label for="isi">Isi</label>
                    <input type="text" name="isi" class="form-control" id="isi" placeholder="Masukkan isi">
                </div>
                <div class="form-group">
                    <label for="class">Class Promo</label>
                    <select id="class" name="class" class="form-control">
                        <option value="first-slide">first-slide</option>
                        <option value="second-slide">second-slide</option>
                    </select>
                </div>
                <br>
                <div class="form-group">
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    function myFunction() {
        var x = document.getElementById("password");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
    CKEDITOR.replace('editor1');
</script>