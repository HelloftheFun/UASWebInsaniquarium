

<!DOCTYPE html>
<html lang="en">

<head>
    <title>FGM Admin Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
    <script src="https://use.fontawesome.com/bb6feaa7cf.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>

    <style>
        .fakeimg {
            height: 200px;
            background: #aaa;
        }
    </style>
</head>

<script>
      function previewImg() {
         const gambar = document.querySelector('#gambar');
         const gambarLabel = document.querySelector('.custom-file-label');
         const imgPreview = document.querySelector('.img-preview');

         // untuk mengganti url
         gambarLabel.textContent = gambar.files[0].name;

         // untuk mengganti preview
         const fileGambar = new FileReader();
         fileGambar.readAsDataURL(gambar.files[0]);

         fileGambar.onload = function(e) {
            imgPreview.src = e.target.result;
         }
      }
   </script>

<body>

    <div class="container" style="margin-top:30px">
        <div class="row">
            <div class="col-md-12">
                <h1>List Promo</h1>
            </div>
        </div>
        <?php if (session()->getFlashdata('msg')) : ?>
                <div class="alert alert-success"><?= session()->getFlashdata('msg') ?></div>
            <?php endif ?>
        <div class="row mb-3 mt-3">
            <div class="col-md-12">
                <a href="<?= base_url('admin/createpromo')?>" class="btn btn-primary">Tambah Produk</a>
            </div>
        </div>
        
        <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>#</th>
                <th>Gambar</th>
                <th>judul</th>
                <th>isi</th>
                <th>Class</th>
                <th>Tombol Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php if($promo) : ?>
        <?php foreach ($promo as $prm) : ?>
            <tr>
                <td><?= $prm['id'] ?></td>
                <td><?= $prm['gambar'] ?></td>
                <td><?= $prm['judul'] ?></td>
                <td><?= $prm['isi'] ?></td>
                <td><?= $prm['class'] ?></td>
                <td><a href="<?= base_url('admin/editpromo/' . $prm['id']) ?>" class="btn btn-info"><i class="fa fa-edit"></i></a>
                <a href="<?= base_url('admin/deletepromo/' . $prm['id']) ?>" class="btn btn-danger" onclick="return confirm('Apakah anda yakin ingin menghapus?')"> <i class="fa fa-trash"></i></a></td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
        </tbody>

        </table>
        <div class="modal fade" id="modalhapus">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
        Apakah anda yakin ingin menghapus data ini?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a href="/admin/deletepromo/<?= $prm['id']; ?>" class="btn btn-primary">Yakin</a>
      </div>
    </div>
  </div>
</div>

     
       




</body>

</html>
<script>
$(document).ready( function () {
    $('#example').DataTable();
} );</script>