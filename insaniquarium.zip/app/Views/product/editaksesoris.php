

<!DOCTYPE html>
<html lang="en">

<head>
    <title>FGM Admin Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css"></script>
    <script src="https://use.fontawesome.com/bb6feaa7cf.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/29.1.0/classic/ckeditor.js"></script>
    <script>
      function previewImg() {
         const gambar = document.querySelector('#gambar');
         const gambarLabel = document.querySelector('.custom-file-label');
         const imgPreview = document.querySelector('.img-preview');

         // untuk mengganti url
         gambarLabel.textContent = gambar.files[0].name;

         // untuk mengganti preview
         const fileGambar = new FileReader();
         fileGambar.readAsDataURL(gambar.files[0]);

         fileGambar.onload = function(e) {
            imgPreview.src = e.target.result;
         }
      }
   </script>

    <style>
        .fakeimg {
            height: 200px;
            background: #aaa;
        }
    </style>
</head>

<body>



    <div class="container">
   <div class="row">
      <div class="col-8">
         <h2 class="my-3">Edit Aksesoris</h2>
         <form action="<?= base_url('/admin/updateaksesoris'); ?>" method="POST" enctype="multipart/form-data">
            <?= csrf_field(); ?>
            <input type="hidden" name="id" value="<?= $aksesoris['id'] ?>" />
            <div class="form-group row">
               <label for="title" class="col-sm-2 col-form-label">Merk Aksesoris</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control <?= ($validation->hasError('merk')) ? 'is-invalid' : ''; ?>" id="merk" name="merk" autofocus value="<?= (old('merk')) ? old('merk') : $aksesoris['merk']?>">
                  <div class="invalid-feedback">
                     <?= $validation->getError('merk'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="tipe" class="col-sm-2 col-form-label">Tipe</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control <?= ($validation->hasError('tipe')) ? 'is-invalid' : ''; ?>" id="tipe" name="tipe" value="<?=$aksesoris['tipe']?>">
                  <div class="invalid-feedback">
                     <?= $validation->getError('tipe'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="slug" class="col-sm-2 col-form-label">Slug</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control <?= ($validation->hasError('slug')) ? 'is-invalid' : ''; ?>" id="slug" name="slug" autofocus value="<?= (old('slug')) ? old('slug') : $aksesoris['slug']?>">
                  <div class="invalid-feedback">
                     <?= $validation->getError('slug'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="pnp" class="col-sm-2 col-form-label">PnP</label>
               <div class="col-sm-10">
               <textarea name="pnp" class="form-control" id="pnp" rows="10" cols="80" <?= ($validation->hasError('pnp')) ? 'is-invalid' : ''; ?> value="<?= old('pnp'); ?>" >
               <?=$aksesoris['pnp']?>
            </textarea>
                  <div class="invalid-feedback">
                     <?= $validation->getError('pnp'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="ctg" class="col-sm-2 col-form-label">Kategori</label>
               <div class="col-sm-10">
               <textarea name="ctg" class="form-control" id="ctg" rows="10" cols="80" <?= ($validation->hasError('ctg')) ? 'is-invalid' : ''; ?> value="<?= old('ctg'); ?>" >
               <?=$aksesoris['ctg']?>
            </textarea>
                  <div class="invalid-feedback">
                     <?= $validation->getError('ctg'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="harga" class="col-sm-2 col-form-label">Harga</label>
               <div class="col-sm-10">
               <textarea name="harga" class="form-control" id="harga" rows="10" cols="80" <?= ($validation->hasError('harga')) ? 'is-invalid' : ''; ?> value="<?= old('harga'); ?>" >
               <?=$aksesoris['harga']?>
            </textarea>
                  <div class="invalid-feedback">
                     <?= $validation->getError('harga'); ?>
                  </div>
               </div>
            </div>
               </div>
            </div>
            <div class="form-group row">
               <div class="col-sm-10">
                  <button type="submit" class="btn btn-primary">Edit Aksesoris</button>
               </div>
            </div>
         </form>

      </div>
   </div>
</div>


</body>

</html>
    