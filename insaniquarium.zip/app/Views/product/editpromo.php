

<!DOCTYPE html>
<html lang="en">

<head>
    <title>FGM Admin Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css"></script>
    <script src="https://use.fontawesome.com/bb6feaa7cf.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/29.1.0/classic/ckeditor.js"></script>
    <script>
      function previewImg() {
         const gambar = document.querySelector('#gambar');
         const gambarLabel = document.querySelector('.custom-file-label');
         const imgPreview = document.querySelector('.img-preview');

         // untuk mengganti url
         gambarLabel.textContent = gambar.files[0].name;

         // untuk mengganti preview
         const fileGambar = new FileReader();
         fileGambar.readAsDataURL(gambar.files[0]);

         fileGambar.onload = function(e) {
            imgPreview.src = e.target.result;
         }
      }
   </script>

    <style>
        .fakeimg {
            height: 200px;
            background: #aaa;
        }
    </style>
</head>

<body>



    <div class="container">
   <div class="row">
      <div class="col-8">
         <h2 class="my-3">Edit Promo</h2>
         <form action="<?= base_url('/admin/updatepromo'); ?>" method="POST" enctype="multipart/form-data">
            <?= csrf_field(); ?>
            <input type="hidden" name="id" value="<?= $promo['id'] ?>" />
            <div class="form-group row">
               <label for="title" class="col-sm-2 col-form-label">Judul Promo</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control <?= ($validation->hasError('judul')) ? 'is-invalid' : ''; ?>" id="judul" name="judul" autofocus value="<?= (old('judul')) ? old('judul') : $promo['judul']?>">
                  <div class="invalid-feedback">
                     <?= $validation->getError('judul'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="isi" class="col-sm-2 col-form-label">Isi</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control <?= ($validation->hasError('isi')) ? 'is-invalid' : ''; ?>" id="isi" name="isi" value="<?=$promo['isi']?>">
                  <div class="invalid-feedback">
                     <?= $validation->getError('isi'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <label for="class" class="col-sm-2 col-form-label">class promo</label>
               <div class="col-sm-10">
                  <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name="class">
                     <option selected><?= $promo['class'] ?> </option>
    <option value="first-slide">first-slide</option>
    <option value="second-slide"> second-slide</option>
                  </select>
                  <div class="invalid-feedback">
                     <?= $validation->getError('class'); ?>
                  </div>
               </div>
            </div>
            <div class="form-group row">
               <div class="col-sm-10">
                  <button type="submit" class="btn btn-primary">Edit Promo</button>
               </div>
            </div>
         </form>

      </div>
   </div>
</div>


</body>

</html>
    