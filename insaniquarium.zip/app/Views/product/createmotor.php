<!DOCTYPE html>
<html lang="en">

<head>
    <title>FGM Admin Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
    <script src="https://use.fontawesome.com/bb6feaa7cf.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
    <script>
      function previewImg() {
         const gambar = document.querySelector('#gambar');
         const gambarLabel = document.querySelector('.custom-file-label');
         const imgPreview = document.querySelector('.img-preview');

         // untuk mengganti url
         gambarLabel.textContent = gambar.files[0].name;

         // untuk mengganti preview
         const fileGambar = new FileReader();
         fileGambar.readAsDataURL(gambar.files[0]);

         fileGambar.onload = function(e) {
            imgPreview.src = e.target.result;
         }
      }
   </script>
    <style>
        .fakeimg {
            height: 200px;
            background: #aaa;
        }
    </style>
</head>
<div class="container">
    <h1>Input Motor</h1>
    <div class="row">
        <div class="col-sm-9">
            <form action="/admin/savemotor" method="POST" enctype="multipart/form-data">
            <div class="form-group row">
               <label for="cover" class="col-sm-2 col-form-label">Foto Produk</label>
               <div class="col-sm-3">
                  <img src="/images/default.png" class="img-thumbnail img-preview">
               </div>
               <div class="col-sm-7">
                  <div class="custom-file">
                     <input type="file" class="custom-file-input  <?= ($validation->hasError('gambar')) ? 'is-invalid' : ''; ?>" id="gambar" name="gambar" onchange="previewImg()">
                     <div class="invalid-feedback">
                        <?= $validation->getError('gambar'); ?>
                     </div> 
                     <label class="custom-file-label" for="gambar">Choose Image ..</label>
                  </div>
               </div>
            </div>
                <div class="form-group">
                    <label for="merk">Merk</label>
                    <input type="text" name="merk" class="form-control" id="merk" placeholder="Masukkan Merk">
                </div>
                <div class="form-group">
                    <label for="tipe">tipe</label>
                    <input type="text" name="tipe" class="form-control" id="tipe" placeholder="Masukkan Tipe">
                </div>
                <div class="form-group">
                    <label for="slug">Slug</label>
                    <input type="text" name="slug" class="form-control" id="slug" placeholder="Masukkan slug">
                </div>
                <div class="form-group">
                    <label for="kategori">Kategori Motor</label>
                    <select id="kategori" name="kategori" class="form-control">
                        <option value="SPORT BIKE">SPORT BIKE</option>
                        <option value="NAKED BIKE">NAKED BIKE</option>
                        <option value="TRAIL BIKE">TRAIL BIKE</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="spesifikasi">Spesifikasi</label>
                    <input type="text" name="spesifikasi" class="form-control" id="spesifikasi" placeholder="Masukkan Jumlah spesifikasi">
                </div>  
                <div class="form-group">
                    <label for="ctg">CTG</label>
                    <select id="ctg" name="ctg" class="form-control">
                        <option value="sprt">Sport</option>
                        <option value="nkd">Naked</option>
                        <option value="trl">Trail</option>
                    </select>
                </div>
                  <div class="form-group">
                    <label for="harga">Harga</label>
                    <input type="text" name="harga" class="form-control" id="harga" placeholder="Masukkan Harga">
                </div>
                <br>
                <div class="form-group">
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    function myFunction() {
        var x = document.getElementById("password");
        if (x.type === "password") {
            x.type = "text";
        } else {
            x.type = "password";
        }
    }
    CKEDITOR.replace('editor1');
</script>