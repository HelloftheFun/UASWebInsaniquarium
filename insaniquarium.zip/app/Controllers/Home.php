<?php

namespace App\Controllers;

use App\Models\IkanModel;
use App\Models\AquariumModel;
use App\Models\PakanModel;
use App\Models\PromoModel;

class Home extends BaseController
{
    protected $ikanmodel;
    protected $aquariummodel;
    protected $pakanmodel;
    protected $promomodel;
    public function __construct()
    {

        $this->ikanmodel = new IkanModel();
        $this->aquariummodel = new AquariumModel();
        $this->pakanmodel = new PakanModel();
        $this->promomodel = new PromoModel();
    }

    public function index()
    {
        $data['ikan'] = $this->ikanmodel->findAll();
        $data['aquarium'] = $this->aquariummodel->findAll();
        $data['aksesorisdanpakan'] = $this->pakanmodel->findAll();
        $data['promo'] = $this->promomodel->findAll();
        
        return view('home/index', $data);
    }
    public function ikan()
    {
        $data ['ikan'] = $this->ikanmodel->findAll();
        return view ('home/ikan', $data);
    }
    public function aquarium()
    {
        $data ['aquarium'] = $this->aquariummodel->findAll();
        return view ('home/aquarium', $data);
    }
    public function pakan()
    {
        $data ['aksesorisdanpakan'] = $this->pakanmodel->findAll();
        return view ('home/pakan', $data);
    }
    public function dtl($id)
    {
        $data ['ikan'] = $this->ikanmodel->getIkan($id);
        return view ('home/dtl', $data);
    }
    public function dtlaqua($id)
    {
        $data ['aquarium'] = $this->aquariummodel->getAquarium($id);
        return view ('home/dtlaqua', $data);
    }
    public function dtlpakan($id)
    {
        $data ['aksesorisdanpakan'] = $this->pakanmodel->getPakan($id);
        return view ('home/dtlpakan', $data);
    }
}
